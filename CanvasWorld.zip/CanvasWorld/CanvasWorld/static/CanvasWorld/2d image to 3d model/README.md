### 2D image to 3D

This was a simple idea that I thought of when someone was talking about manipulating image pixes according to the brightness level of that pixel. 

Altho it is not the most perfect script it was still fun to play around the idea of using the total r + g + b value of a pixel to get a z value.


![alt][logo] - > ![alt][logo1]

[logo]: http://pictify.saatchigallery.com/files/works/pink-gerbera-daisies-1409848544_org.jpg ""

[logo1]: https://github.com/kgz/CanvasWorld/blob/master/2d%20image%20to%203d%20model/sample.gif?raw=true ""


### Side note...
There are many flaws with this:
- If theres a white background, there will be a border around object, (maybe with a bit of adjusting it might be ok).

- This relies on the object being symmetrical (or near enough); as can be seen with the flowers, the left most flower in the 3d image doesn't look like a flower at all.