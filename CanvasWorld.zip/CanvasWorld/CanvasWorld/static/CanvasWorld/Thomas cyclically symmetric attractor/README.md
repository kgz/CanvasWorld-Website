### Thomas cyclically symmetric attractor
